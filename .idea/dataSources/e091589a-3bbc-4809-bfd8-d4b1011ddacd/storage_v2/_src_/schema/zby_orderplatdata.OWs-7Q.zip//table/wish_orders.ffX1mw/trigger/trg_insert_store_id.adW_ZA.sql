create definer = erptest_root@`%` trigger trg_insert_store_id
    before insert
    on wish_orders
    for each row
BEGIN
declare v_store_id int(11); 
if NEW.store_id is null then 
    select id into v_store_id from zby_masterdata.store where sell_id = NEW.client_id and `status`=1; 
    set NEW.store_id = v_store_id;
end if;
END;


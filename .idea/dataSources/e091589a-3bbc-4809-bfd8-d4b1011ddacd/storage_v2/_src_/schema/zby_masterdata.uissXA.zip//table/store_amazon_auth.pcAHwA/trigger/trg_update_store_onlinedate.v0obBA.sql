create definer = erptest_root@`%` trigger trg_update_store_onlinedate
    after update
    on store_amazon_auth
    for each row
BEGIN
UPDATE zby_masterdata.store SET latest_online_date=NEW.latest_online_date WHERE id = NEW.store_id;
END;


create definer = erptest_root@`%` trigger goods_sku_only_is_main_or_is_sub
    before update
    on goods_sku
    for each row
BEGIN
          IF (NEW.is_main_sku=1 or NEW.is_sub=1) AND ((NEW.is_main_sku=1 AND OLD.is_sub=1) OR (OLD.is_main_sku=1 AND NEW.is_sub=1))
          THEN
               SIGNAL SQLSTATE '50000'
                    SET MESSAGE_TEXT = 'one goods sku can only be main or be sub, cannot be both at one time';
          END IF;
     END;

